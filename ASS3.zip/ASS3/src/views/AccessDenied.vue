<template>
    <div class="col-12 col-md-11">
      <h1>Access Denied</h1>
      <p>You do not have access to view this page. Please <router-link to="/login">login</router-link>.</p>
    </div>
  </template>
  
  <script setup>
  </script>
  