<template>
    <div class="container d-flex flex-column justify-content-center align-items-center col-12 col-md-10" style="height: 100vh;">
      <h1>Congratulations, you have successfully registered!</h1>
      <p><router-link to="/login">Click here to go back to the login page.</router-link></p>
    </div>
  </template>